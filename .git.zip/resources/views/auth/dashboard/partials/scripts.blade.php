	<!-- Common Javascript -->
	<script src="{{asset('admin/plugins/jquery/jquery-3.5.1.min.js')}}"></script>
	<script src="{{asset('admin/js/bootstrap.bundle.min.js')}}"></script>
	<script src="{{asset('admin/plugins/simplebar/simplebar.min.js')}}"></script>
	<script src="{{asset('admin/plugins/jquery-zoom/jquery.zoom.min.js')}}"></script>
	<script src="{{asset('admin/plugins/slick/slick.min.js')}}"></script>

	<!-- Chart -->
	<script src="{{asset('admin/plugins/charts/Chart.min.js')}}"></script>
	<script src="{{asset('admin/js/chart.js')}}"></script>

	<!-- Google map chart -->
	<script src="{{asset('admin/plugins/charts/google-map-loader.js')}}"></script>
	<script src="{{asset('admin/plugins/charts/google-map.js')}}"></script>

	<!-- Date Range Picker -->
	<script src="{{asset('admin/plugins/daterangepicker/moment.min.js')}}"></script>
    <script src="{{asset('admin/plugins/daterangepicker/daterangepicker.js')}}"></script>
	<script src="{{asset('admin/js/date-range.js')}}"></script>

	<!-- Option Switcher -->
	<script src="{{asset('admin/plugins/options-sidebar/optionswitcher.js')}}"></script>

	<!-- Ekka Custom -->
	<script src="{{asset('admin/js/ekka.js')}}"></script>

